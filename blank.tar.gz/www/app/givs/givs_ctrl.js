angular.module('starter.controllers', [])

.controller('givs_ctrl', function($scope, $http) {
  $scope.items = [];
  $scope.loadMoreGiv = function() {
    $http.get('json/givs.json').success(function(items) {
       $scope.givs=items;
       console.log("items success");
     
       //$scope.$broadcast('scroll.infiniteScrollComplete');

    $scope.$broadcast('scroll.infiniteScrollComplete');

    
    });
  };

  $scope.moreGivCanBeLoaded = function() {
  	return true;

  }

  $scope.$on('$stateChangeSuccess', function() {
    $scope.loadMoreGiv();
  });
}
);