angular.module('starter.controllers', [])

.controller('home', function($scope) {

})