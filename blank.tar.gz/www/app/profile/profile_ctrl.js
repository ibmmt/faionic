angular.module('starter.controllers', [])

.controller('forget_password', function($scope) {
	console.log("hai")
})
.controller('login', function($scope) {
	console.log("login")
})
.controller('profile_edit', function($scope) {
	console.log("profile_edit")
})
.controller('signup', function($scope) {
	console.log("signup")
})
